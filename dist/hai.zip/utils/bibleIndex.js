"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BIBLE_INDEXES = [
    { keyword: 'Kejadian', en: 'genesis', jp: '創世記' },
    { keyword: 'Keluaran', en: 'exodus', jp: '出エジプト記' },
    { keyword: 'Imamat', en: 'leviticus', jp: 'レビ記' },
    { keyword: 'Bilangan', en: 'numbers', jp: '民数記' },
    { keyword: 'Ulangan', en: 'deuteronomy', jp: '申命記' },
    { keyword: 'Yosua', en: 'joshua', jp: 'ヨシュア記' },
    { keyword: 'Hakim-Hakim', en: 'judges', jp: '士師記' },
    { keyword: 'Rut', en: 'ruth', jp: 'ルツ記' },
    { keyword: '1 Samuel', en: 'first_samuel', jp: 'サムエル記　第一' },
    { keyword: '2 Samuel', en: 'second_samuel', jp: 'サムエル記　第二' },
    { keyword: '1 Raja-Raja', en: 'first_king', jp: '列王記　第一' },
    { keyword: '2 Raja-Raja', en: 'second_king', jp: '列王記　第二' },
    { keyword: '1 Tawarikh', en: 'first_chronicles', jp: '歴代誌　第一' },
    { keyword: '2 Tawarikh', en: 'second_chronicles', jp: '歴代誌　第二' },
    { keyword: 'Ezra', en: 'ezra', jp: 'エズラ記' },
    { keyword: 'Nehemia', en: 'nehemiah', jp: 'ネヘミヤ記' },
    { keyword: 'Ester', en: 'esther', jp: 'エステル記' },
    { keyword: 'Ayub', en: 'job', jp: 'ヨブ記' },
    { keyword: 'Mazmur', en: 'psalms', jp: '詩篇' },
    { keyword: 'Amsal', en: 'proverbs', jp: '箴言' },
    { keyword: 'Pengkhotbah', en: 'ecclesiastes', jp: '伝道者の書' },
    { keyword: 'Kidung Agung', en: 'song_of_songs', jp: '雅歌' },
    { keyword: 'Yesaya', en: 'isaiah', jp: 'イザヤ書' },
    { keyword: 'Yeremia', en: 'jeremiah', jp: 'エレミヤ書' },
    { keyword: 'Ratapan', en: 'lamentations', jp: '哀歌' },
    { keyword: 'Yehezkiel', en: 'ezekiel', jp: 'エゼキエル書' },
    { keyword: 'Daniel', en: 'daniel', jp: 'ダニエル書' },
    { keyword: 'Hosea', en: 'hosea', jp: 'ホセア書' },
    { keyword: 'Yoel', en: 'joel', jp: 'ヨエル書' },
    { keyword: 'Amos', en: 'amos', jp: 'アモス書' },
    { keyword: 'Obaja', en: 'obadiah', jp: 'オバデヤ書' },
    { keyword: 'Yunus', en: 'jonah', jp: 'ヨナ書' },
    { keyword: 'Mikha', en: 'micah', jp: 'ミカ書' },
    { keyword: 'Nahum', en: 'nahum', jp: 'ナホム書' },
    { keyword: 'Habakuk', en: 'habakkuk', jp: 'ハバクク書' },
    { keyword: 'Zefanya', en: 'zephaniah', jp: 'ゼパニヤ書' },
    { keyword: 'Hagai', en: 'haggai', jp: 'ハガイ書' },
    { keyword: 'Zakharia', en: 'zechariah', jp: 'ゼカリヤ書' },
    { keyword: 'Maleakhi', en: 'malachi', jp: 'マラキ書' },
    { keyword: 'Matius' },
    { keyword: 'Markus' },
    { keyword: 'Lukas' },
    { keyword: 'Yohanes' },
    { keyword: 'Kisah Para Rasul' },
    { keyword: 'Roma' },
    { keyword: '1 Korintus' },
    { keyword: '2 Korintus' },
    { keyword: 'Galatia' },
    { keyword: 'Efesus' },
    { keyword: 'Filipi' },
    { keyword: 'Kolose' },
    { keyword: '1 Tesalonika' },
    { keyword: '2 Tesalonika' },
    { keyword: '1 Timotius' },
    { keyword: '2 Timotius' },
    { keyword: 'Titus' },
    { keyword: 'Filemon' },
    { keyword: 'Ibrani' },
    { keyword: 'Yakobus' },
    { keyword: '1 Petrus' },
    { keyword: '2 Petrus' },
    { keyword: '1 Yohanes' },
    { keyword: '2 Yohanes' },
    { keyword: '3 Yohanes' },
    { keyword: 'Yudas' },
    { keyword: 'Wahyu' },
];
exports.getBibleIndex = (keyword) => {
    let index = -1;
    exports.BIBLE_INDEXES.map(x => x.keyword.toLowerCase()).forEach((value, i) => {
        if (value.includes(keyword.toLowerCase())) {
            index = i;
        }
    });
    if (index === -1) {
        throw 'Index Not Found';
    }
    // add book index
    const bibleIndex = Object.assign({}, exports.BIBLE_INDEXES[index], { bookId: index + 1 });
    return bibleIndex;
};
//# sourceMappingURL=bibleIndex.js.map