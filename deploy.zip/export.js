"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const TEST = 'test';
exports.default = TEST;
//# sourceMappingURL=export.js.map